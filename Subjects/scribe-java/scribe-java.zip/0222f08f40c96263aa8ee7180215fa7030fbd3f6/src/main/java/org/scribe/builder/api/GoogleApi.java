package org.scribe.builder.api;

public class GoogleApi extends DefaultApi10a
{
  @Override
  public String getAccessTokenEndpoint()
  {
    throw new UnsupportedOperationException();
  }

  @Override
  public String getRequestTokenEndpoint()
  {
    throw new UnsupportedOperationException();
  }
}
