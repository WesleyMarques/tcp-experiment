package org.scribe.services;

public interface TimestampService
{

  public String getTimestampInSeconds();

  public String getNonce();
}
