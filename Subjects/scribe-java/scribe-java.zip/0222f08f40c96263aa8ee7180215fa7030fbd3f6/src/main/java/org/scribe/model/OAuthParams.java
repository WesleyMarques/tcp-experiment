package org.scribe.model;

public class OAuthParams
{

}
